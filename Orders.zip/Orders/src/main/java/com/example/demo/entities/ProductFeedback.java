package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ProductFeedback {
   
	@Id
   @GeneratedValue(strategy=GenerationType.AUTO)
   Integer productfeedbackId;
   Integer productId;
   Integer Rating;
   String userId;
   String review;
   
public Integer getProductfeedbackId() {
	return productfeedbackId;
}
public void setProductfeedbackId(Integer productfeedbackId) {
	this.productfeedbackId = productfeedbackId;
}
public Integer getProductId() {
	return productId;
}
public void setProductId(Integer productId) {
	this.productId = productId;
}
public Integer getRating() {
	return Rating;
}
public void setRating(Integer rating) {
	Rating = rating;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getReview() {
	return review;
}
public void setReview(String review) {
	this.review = review;
}
@Override
public String toString() {
	return "ProductFeedback [ProductfeedbackId=" + productfeedbackId + ", ProductId=" + productId + ", Rating=" + Rating
			+ ", userId=" + userId + ", review=" + review + "]";
}
public ProductFeedback(Integer ProductfeedbackId, Integer ProductId, Integer rating, String userId, String review) {
	super();
	this.productfeedbackId = ProductfeedbackId;
	this.productId = ProductId;
	Rating = rating;
	this.userId = userId;
	this.review = review;
}
public ProductFeedback() {
	super();
	// TODO Auto-generated constructor stub
}
   
   
}
