package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SellerFeedback {
   
	@Id
   @GeneratedValue(strategy=GenerationType.AUTO)
   Integer sellerfeedbackId;
   Integer sellerId;
   Integer Rating;
   String userId;
   String review;
   
public Integer getSellerfeedbackId() {
	return sellerfeedbackId;
}
public void setSellerfeedbackId(Integer sellerfeedbackId) {
	this.sellerfeedbackId = sellerfeedbackId;
}
public Integer getSellerId() {
	return sellerId;
}
public void setSellerId(Integer sellerId) {
	this.sellerId = sellerId;
}
public Integer getRating() {
	return Rating;
}
public void setRating(Integer rating) {
	Rating = rating;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getReview() {
	return review;
}
public void setReview(String review) {
	this.review = review;
}
@Override
public String toString() {
	return "SellerFeedback [sellerfeedbackId=" + sellerfeedbackId + ", sellerId=" + sellerId + ", Rating=" + Rating
			+ ", userId=" + userId + ", review=" + review + "]";
}
public SellerFeedback(Integer sellerfeedbackId, Integer sellerId, Integer rating, String userId, String review) {
	super();
	this.sellerfeedbackId = sellerfeedbackId;
	this.sellerId = sellerId;
	Rating = rating;
	this.userId = userId;
	this.review = review;
}
public SellerFeedback() {
	super();
	// TODO Auto-generated constructor stub
}
   
   
}
