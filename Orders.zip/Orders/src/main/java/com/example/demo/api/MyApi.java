package com.example.demo.api;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.Orders;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductFeedback;
import com.example.demo.entities.SellerFeedback;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.ProductFeedbackRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.SellerFeedbackRepository;

@RestController
@RequestMapping("/orders")
public class MyApi { 
    
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	ProductFeedbackRepository productFeedbackRepository ;
	
	@Autowired
	SellerFeedbackRepository sellerFeedbackRepository;
	
	@GetMapping("/view/{userId}")
	public Object GetOrders(@PathVariable String userId) {
	    List<Orders> orders= orderRepository.findByUserId(userId);
	    return orders;
	}
	
	
	@PostMapping("/cancelOrder/{orderId}")
	public Object CancelOrders(@PathVariable Integer orderId) {
	    Optional<Orders> orders=orderRepository.findById(orderId);
		if(orders.isEmpty())
	     return "NO ORDER FOUND";
		
		System.out.println(orders.get().getOrderStatus());
		if(!orders.get().getOrderStatus().equals("OPEN"))
	     return "ORDER IS NOT IN OPEN STATE";		
		orders.get().setOrderStatus("CANCELLED");
		orderRepository.save(orders.get());
		return "ORDER SUCCESSFULLY CANCELLED IF ALREADY PAID REFUND WILL BE CREDITED WITHIN 7 DAYS";
	}
	
	@PostMapping("/returnOrder/{orderId}")
	public Object ReturnOrders(@PathVariable Integer orderId){ 
	    Optional<Orders> orders=orderRepository.findById(orderId);
		if(orders.isEmpty())
		 return "NO ORDER FOUND";
		if(!orders.get().getOrderStatus().equals("DELIVERED"))
		 return "ORDER IS NOT DELIVERED YET";		
		
		orders.get().setOrderStatus("RETURNED");
		orderRepository.save(orders.get());
		return "RETURN REQUEST ACCEPTED.. PICK-UP WILL BE ASSIGNED SOON";
	}
	
	
	@PostMapping("/ProductFeedback")
	public Object productFeedback(@RequestBody ProductFeedback productFeedback) {
		ProductFeedback feedback = new ProductFeedback();
		feedback.setUserId(productFeedback.getUserId());
		feedback.setProductId(productFeedback.getProductId());
		feedback.setRating(productFeedback.getRating());
		feedback.setReview(productFeedback.getReview());
		productFeedbackRepository.save(feedback);
		return "FEEDBACK SUBMITTED";
	}
	
	
	@PostMapping("/SellerFeedback")
	public Object sellerFeedback(@RequestBody SellerFeedback sellerFeedback) {
		SellerFeedback feedback = new SellerFeedback();
		feedback.setUserId(sellerFeedback.getUserId());
		feedback.setSellerId(sellerFeedback.getSellerId());
		feedback.setRating(sellerFeedback.getRating());
		feedback.setReview(sellerFeedback.getReview());
		sellerFeedbackRepository.save(feedback);
		return "FEEDBACK SUBMITTED";
	}
}
