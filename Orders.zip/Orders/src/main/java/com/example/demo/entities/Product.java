package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="product")
public class Product {
    
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Integer productId;
    String productName;
    String productCategory;
    Integer sellerId;
    
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public Integer getSellerId() {
		return sellerId;
	}
	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}
	@Override
	public String toString() {
		return "Products [productId=" + productId + ", productName=" + productName + ", productCategory="
				+ productCategory + ", sellerId=" + sellerId + "]";
	}
	public Product(Integer productId, String productName, String productCategory,Integer sellerId) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.sellerId = sellerId;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
