package com.example.demo.entities;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity(name="orders")
public class Orders {
	
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer orderId;
    @JoinColumn(name="productId")
    @ManyToOne(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
    Product product;
    String orderStatus;
    String date;
    String userId;
	
    public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", product=" + product + ", orderStatus=" + orderStatus + ", date="
				+ date + ", userId=" + userId + "]";
	}
	
	public Orders(Integer orderId, Product product, String orderStatus, String date, String userId) {
		super();
		this.orderId = orderId;
		this.product = product;
		this.orderStatus = orderStatus;
		this.date = date;
		this.userId = userId;
	}
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}
   
}
